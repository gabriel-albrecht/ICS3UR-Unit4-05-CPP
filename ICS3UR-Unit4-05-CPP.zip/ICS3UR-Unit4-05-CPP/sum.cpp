// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program adds positive numbers

#include <iostream>
#include <string>

int main() {
    int loopCounter = 0;
    int sum = 0;
    int howManyNumbers = 0;
    std::string numStr;
    int num = 0;
    std::string timString;

    // input
    std::cout << "How many numbers will you add?: ";
    std::cin >> timString;
    std::cout << "" << std::endl;

    try {
        // process & output
        howManyNumbers = std::stoi(timString);
        while (loopCounter < howManyNumbers) {
            std::cout << "Enter a positive number: ";
            std::cin >> numStr;
            num = std::stoi(numStr);
            if (num < 0) {
                loopCounter += 1;
                continue;
            } else {
                sum += num;
                loopCounter += 1;
            }
        } std::cout << "" << std::endl;
        std::cout << "The sum of the positive numbers is " << sum
        << std::endl;
    } catch (std::invalid_argument) {
        std::cout << "" << std::endl;
        std::cout << "That is not an integer" << std::endl;
    }
}
